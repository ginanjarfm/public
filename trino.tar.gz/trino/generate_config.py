import os

os.system("env | grep '^TRINO'. > out")
with open("out", "r") as f:
    for catalog in f.readlines():
        splitter = catalog.find("=")
        catalog_name = catalog[0:splitter].replace("TRINO_", "").lower()
        catalog_value = (
            catalog[1 + splitter :]
            .replace("\\n", "\n")
            .replace('"', "")
            .replace("'", "")
        )
        with open(f"catalog/{catalog_name}.properties", "w") as file:
            file.write(catalog_value)
