/*
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.trino.udfs;

import io.airlift.slice.Slice;
import io.airlift.slice.Slices;
import io.trino.spi.function.Description;
import io.trino.spi.function.ScalarFunction;
import io.trino.spi.function.SqlNullable;
import io.trino.spi.function.SqlType;
import io.trino.spi.type.StandardTypes;
import org.json.JSONObject;

import static io.airlift.slice.Slices.utf8Slice;
import static io.trino.spi.type.StandardTypes.VARCHAR;

import java.lang.Exception;
import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public final class ExecuteNative {
    private ExecuteNative() {
    }

    @Description("UDF to incremental etl between two tables using native connector")
    @ScalarFunction("custom_psql_delete_insert")
    @SqlType(VARCHAR)
    public static Slice custom_psql_delete_insert(
            @SqlType(VARCHAR) Slice catalog,
            @SqlType(VARCHAR) Slice schema,
            @SqlType(VARCHAR) Slice table,
            @SqlType(VARCHAR) Slice column) {

        String raw_string = null;
        String DB_URL = null;
        String USER = null;
        String PASS = null;

        try {
            Scanner scanner = new Scanner(new File(
                    String.format("/etc/trino/catalog/%s.properties", catalog.toStringUtf8().replace("\"", ""))));
            while (scanner.hasNextLine()) {
                raw_string = scanner.nextLine();
                String[] splitted_raw_string = raw_string.split("=");
                if (splitted_raw_string[0].equals("connection-url")) {
                    DB_URL = splitted_raw_string[1];
                } else if (splitted_raw_string[0].equals("connection-user")) {
                    USER = splitted_raw_string[1];
                } else if (splitted_raw_string[0].equals("connection-password")) {
                    PASS = splitted_raw_string[1];

                }
            }
            scanner.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        String returned_value = null;
        Connection conn = null;
        Statement stmt = null;
        String sql = null;

        try {
            Class.forName("org.postgresql.Driver");
            conn = DriverManager.getConnection(DB_URL, USER, PASS);
            conn.setAutoCommit(false);

            stmt = conn.createStatement();

            sql = String
                    .format("""
                            DELETE FROM "%s"."%s"
                            WHERE MD5(ROW(%s)::TEXT) IN (SELECT MD5(ROW(%s)::TEXT) FROM "%s"."%s");
                            """,
                            schema.toStringUtf8(),
                            table.toStringUtf8(),
                            column.toStringUtf8(),
                            column.toStringUtf8(),
                            schema.toStringUtf8(),
                            table.toStringUtf8() + "__dbt_tmp");

            stmt.executeUpdate(sql);

            sql = String.format(
                    """
                            SELECT
                                'INSERT INTO "%s"."%s"(' || string_agg('"' || column_name || '"', ', ' ORDER BY
                                ordinal_position ASC) || ')' ||
                                E'\nSELECT ' || string_agg('"' || column_name || '"', ', ' ORDER BY
                                ordinal_position ASC) || E'\nFROM "' || table_schema || '"."' || table_name || '__dbt_tmp";' AS sql
                            FROM
                                information_schema.columns
                            WHERE
                                    table_schema = '%s'
                                AND table_name = '%s'
                            GROUP BY table_name, table_schema
                            """,
                    schema.toStringUtf8(),
                    table.toStringUtf8(),
                    schema.toStringUtf8(),
                    table.toStringUtf8());
            ResultSet rs = stmt.executeQuery(sql);

            while (rs.next()) {
                returned_value = rs.getString("sql");
            }
            rs.close();

            stmt.executeUpdate(returned_value);

            stmt.close();
            conn.commit();
            conn.close();

            returned_value = "Incremental Insert Success";
        } catch (Exception e) {
            returned_value = e.getClass().getName() + ": " + e.getMessage();
            throw new java.lang.Error(e);
        }

        return utf8Slice(returned_value);
    }

}
