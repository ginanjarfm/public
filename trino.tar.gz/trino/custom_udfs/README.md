# Trino Custom UDFS

Extension untuk nambah custom function

## Cara Pakai

- Pastikan sudah ada maven, jalankan kode berikut untuk build jar nya dan masukan ke dockerfile trino
  ```bash
  mvn clean package -DskipTests -Dair.check.skip-checkstyle ;
  ```
